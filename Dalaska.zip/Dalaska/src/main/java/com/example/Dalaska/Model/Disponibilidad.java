package com.example.Dalaska.Model;

import jakarta.persistence.*;

@Entity
public class Disponibilidad {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long idDisponibilidad;

    private Integer cantidadDisponible;

    private boolean disponible; // Nuevo campo

    @ManyToOne
    @JoinColumn(name = "producto_id")
    private Productos producto;

    public Disponibilidad() {
    }

    public Disponibilidad(Long idDisponibilidad, Integer cantidadDisponible, boolean disponible, Productos producto) {
        this.idDisponibilidad = idDisponibilidad;
        this.cantidadDisponible = cantidadDisponible;
        this.disponible = disponible;
        this.producto = producto;
    }

    public Long getIdDisponibilidad() {
        return idDisponibilidad;
    }

    public void setIdDisponibilidad(Long idDisponibilidad) {
        this.idDisponibilidad = idDisponibilidad;
    }

    public Integer getCantidadDisponible() {
        return cantidadDisponible;
    }

    public void setCantidadDisponible(Integer cantidadDisponible) {
        this.cantidadDisponible = cantidadDisponible;
    }

    public boolean isDisponible() {
        return disponible;
    }

    public void setDisponible(boolean disponible) {
        this.disponible = disponible;
    }

    public Productos getProducto() {
        return producto;
    }

    public void setProducto(Productos producto) {
        this.producto = producto;
    }

    @Override
    public String toString() {
        return "Disponibilidad{" +
                "idDisponibilidad=" + idDisponibilidad +
                ", cantidadDisponible=" + cantidadDisponible +
                ", disponible=" + disponible +
                ", producto=" + producto +
                '}';
    }
}
