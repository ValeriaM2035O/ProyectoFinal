package com.example.Dalaska.Service;

import com.example.Dalaska.Model.Cocina;
import com.example.Dalaska.Repository.CocinaRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
@Service
public class CocinaService {

    @Autowired
    private CocinaRepository cocinaRepository;

    public List<Cocina> getAllCocinas() {
        return cocinaRepository.findAll();
    }
    public Optional<Cocina> getCocinaById(Long id) {
        return cocinaRepository.findById(id);
    }
    public Cocina saveCocina(Cocina cocina) {
        return cocinaRepository.save(cocina);
    }
    public void updateCocina(Long id, Cocina cocina) {
        if (cocinaRepository.existsById(id)) {
            cocina.setId(id);
            cocinaRepository.save(cocina);
        }
    }
    public void deleteCocina(Long id) {
        cocinaRepository.deleteById(id);

}
    public List<Object[]> findCocinaPedidosDescripcionOrderedByFecha() {
        return cocinaRepository.findCocinaPedidosDescripcionOrderedByFecha();
    }
}
