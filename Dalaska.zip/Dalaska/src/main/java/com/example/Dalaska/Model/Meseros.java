package com.example.Dalaska.Model;

import jakarta.persistence.*;

import java.util.ArrayList;
import java.util.List;

@Entity
public class Meseros {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long idMeseros; // Cambié el nombre a 'id' para mayor claridad
    private String nombre;

    @OneToMany(mappedBy = "mesero", cascade = CascadeType.ALL)
    private List<Pedidos> pedidos = new ArrayList<>();

    public Meseros() {
    }

    public Meseros(Long id, String nombre, List<Pedidos> pedidos) {
        this.idMeseros = id;
        this.nombre = nombre;
        this.pedidos = pedidos;
    }

    public Long getId() {
        return idMeseros;
    }

    public void setId(Long id) {
        this.idMeseros = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public List<Pedidos> getPedidos() {
        return pedidos;
    }

    public void setPedidos(List<Pedidos> pedidos) {
        this.pedidos = pedidos;
    }

    @Override
    public String toString() {
        return "Meseros{" +
                "id=" + idMeseros +
                ", nombre='" + nombre + '\'' +
                ", pedidos=" + pedidos +
                '}';
    }
}
