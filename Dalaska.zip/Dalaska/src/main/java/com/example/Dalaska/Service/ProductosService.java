package com.example.Dalaska.Service;

import com.example.Dalaska.Model.Productos;
import com.example.Dalaska.Repository.ProductosRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
@Service
public class ProductosService {

    @Autowired
    private ProductosRepository productosRepository;

    public List<Productos> getAllProductos() {
        return productosRepository.findAll();
    }

    public Optional<Productos> getProductoById(Long id) {
        return productosRepository.findById(id);
    }

    public Productos saveProducto(Productos producto) {
        return productosRepository.save(producto);
    }

    public void updateProducto(Long id, Productos producto) {
        if (productosRepository.existsById(id)) {
            producto.setId(id);
            productosRepository.save(producto);
        }
    }

    public void deleteProducto(Long id) {
        productosRepository.deleteById(id);
    }
    public List<Productos> findAvailableProducts() {
        return productosRepository.findAvailableProducts();
    }

}
