package com.example.Dalaska.Model;

import jakarta.persistence.*;

@Entity
public class DescripcionPedidos {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long idDescripcionPedidos;
    private String detalles;

    @OneToOne(mappedBy = "descripcion", cascade = CascadeType.ALL)
    private Pedidos pedido;

    public DescripcionPedidos() {
    }

    public DescripcionPedidos(Long idDescripcionPedidos, String detalles, Pedidos pedido) {
        this.idDescripcionPedidos = idDescripcionPedidos;
        this.detalles = detalles;
        this.pedido = pedido;
    }
    public Long getId() {
        return idDescripcionPedidos;
    }
    public Long getIdDescripcionPedidos() {
        return idDescripcionPedidos;
    }

    public void setIdDescripcionPedidos(Long idDescripcionPedidos) {
        this.idDescripcionPedidos = idDescripcionPedidos;
    }

    public String getDetalles() {
        return detalles;
    }

    public void setDetalles(String detalles) {
        this.detalles = detalles;
    }

    public Pedidos getPedido() {
        return pedido;
    }

    public void setPedido(Pedidos pedido) {
        this.pedido = pedido;
    }

    @Override
    public String toString() {
        return "DescripcionPedidos{" +
                "idDescripcionPedidos=" + idDescripcionPedidos +
                ", detalles='" + detalles + '\'' +
                ", pedido=" + pedido +
                '}';
    }

    public void setId(Long id) {

    }
}
