package com.example.Dalaska;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DalaskaApplication {

	public static void main(String[] args) {
		SpringApplication.run(DalaskaApplication.class, args);
	}

}
