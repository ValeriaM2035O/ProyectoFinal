package com.example.Dalaska.Service;

import com.example.Dalaska.Model.Pedidos;
import com.example.Dalaska.Repository.PedidosRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
@Service
public class PedidosService {

    @Autowired
    private PedidosRepository pedidosRepository;

    public List<Pedidos> getAllPedidos() {
        return pedidosRepository.findAll();
    }

    public Optional<Pedidos> getPedidoById(Long id) {
        return pedidosRepository.findById(id);
    }

    public Pedidos savePedido(Pedidos pedido) {
        return pedidosRepository.save(pedido);
    }

    public void updatePedido(Long id, Pedidos pedido) {
        if (pedidosRepository.existsById(id)) {
            pedido.setId(id);
            pedidosRepository.save(pedido);
        }
    }

    public void deletePedido(Long id) {
        pedidosRepository.deleteById(id);

    }

    public List<Pedidos> findAllPedidosOrderedByDate() {
        return pedidosRepository.findAllPedidosOrderedByDate();
    }
    public List<Object[]> findPedidosByMesero(Long meseroId) {
        return pedidosRepository.findPedidosByMesero(meseroId);
    }

    public List<Object[]> findAllTableData() {
        return pedidosRepository.findAllTableData();
    }
}
