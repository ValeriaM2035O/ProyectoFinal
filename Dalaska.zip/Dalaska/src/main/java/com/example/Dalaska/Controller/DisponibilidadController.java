package com.example.Dalaska.Controller;

import com.example.Dalaska.Model.Disponibilidad;
import com.example.Dalaska.Service.DisponibilidadService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping ("/disponibilidad")
public class DisponibilidadController {

    @Autowired
    private DisponibilidadService disponibilidadService;

    @GetMapping("/todos")
    public List<Disponibilidad> getAllDisponibilidades() {
        return disponibilidadService.getAllDisponibilidades();
    }

    @GetMapping("/{id}")
    public Optional<Disponibilidad> getDisponibilidadById(@PathVariable Long id) {
        return disponibilidadService.getDisponibilidadById(id);
    }

    @PostMapping("/guardar")
    public ResponseEntity<String> saveDisponibilidad(@RequestBody Disponibilidad disponibilidad) {
        Disponibilidad nuevaDisponibilidad = disponibilidadService.saveDisponibilidad(disponibilidad);
        return ResponseEntity.status(HttpStatus.CREATED)
                .body("Disponibilidad registrada con éxito. ID: " + nuevaDisponibilidad.getIdDisponibilidad());
    }

    @PutMapping("/{id}/actualizar")
    public ResponseEntity<String> updateDisponibilidad(@PathVariable Long id, @RequestBody Disponibilidad disponibilidad) {
        disponibilidadService.updateDisponibilidad(id, disponibilidad);
        return ResponseEntity.ok("Disponibilidad actualizada con éxito. ID: " + id);
    }

    @DeleteMapping("/eliminar/{id}")
    public ResponseEntity<String> deleteDisponibilidad(@PathVariable Long id) {
        disponibilidadService.deleteDisponibilidad(id);
        return ResponseEntity.ok("Disponibilidad eliminada con éxito. ID: " + id);
    }
}
