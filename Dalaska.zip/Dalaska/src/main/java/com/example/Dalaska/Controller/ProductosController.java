package com.example.Dalaska.Controller;

import com.example.Dalaska.Model.Productos;
import com.example.Dalaska.Service.ProductosService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping ("/productos")
public class ProductosController {

    @Autowired
    private ProductosService productosService;

    @GetMapping("/todos")
    public List<Productos> getAllProductos() {
        return productosService.getAllProductos();
    }

    @GetMapping("/{id}")
    public Optional<Productos> getProductoById(@PathVariable Long id) {
        return productosService.getProductoById(id);
    }

    @PostMapping("/guardar")
    public ResponseEntity<String> saveProducto(@RequestBody Productos producto) {
        Productos nuevoProducto = productosService.saveProducto(producto);
        return ResponseEntity.status(HttpStatus.CREATED)
                .body("Producto registrado con éxito. ID: " + nuevoProducto.getId());
    }

    @PutMapping("/{id}/actualizar")
    public ResponseEntity<String> updateProducto(@PathVariable Long id, @RequestBody Productos producto) {
        productosService.updateProducto(id, producto);
        return ResponseEntity.ok("Producto actualizado con éxito. ID: " + id);
    }

    @DeleteMapping("/eliminar/{id}")
    public ResponseEntity<String> deleteProducto(@PathVariable Long id) {
        productosService.deleteProducto(id);
        return ResponseEntity.ok("Producto eliminado con éxito. ID: " + id);
    }
    @GetMapping("/disponibilidad")
    public ResponseEntity<List<Productos>> getAvailableProducts() {
        List<Productos> result = productosService.findAvailableProducts();
        return ResponseEntity.ok(result);
    }
}

