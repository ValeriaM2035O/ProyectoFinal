package com.example.Dalaska.Controller;

import com.example.Dalaska.Model.Cocina;
import com.example.Dalaska.Service.CocinaService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping ("/cocina")
public class CocinaController {
    @Autowired
    private CocinaService cocinaService;

    @GetMapping("/todos")
    public List<Cocina> getAllCocinas() {
        return cocinaService.getAllCocinas();
    }

    @GetMapping("/{id}")
    public Optional<Cocina> getCocinaById(@PathVariable Long id) {
        return cocinaService.getCocinaById(id);
    }

    @PostMapping("/guardar")
    public ResponseEntity<String> saveCocina(@RequestBody Cocina cocina) {
        Cocina nuevaCocina = cocinaService.saveCocina(cocina);
        return ResponseEntity.status(HttpStatus.CREATED)
                .body("Cocina registrada con éxito. ID: " + nuevaCocina.getId());
    }

    @PutMapping("/{id}/actualizar")
    public ResponseEntity<String> updateCocina(@PathVariable Long id, @RequestBody Cocina cocina) {
        cocinaService.updateCocina(id, cocina);
        return ResponseEntity.ok("Cocina actualizada con éxito. ID: " + id);
    }

    @DeleteMapping("/eliminar/{id}")
    public ResponseEntity<String> deleteCocina(@PathVariable Long id) {
        cocinaService.deleteCocina(id);
        return ResponseEntity.ok("Cocina eliminada con éxito. ID: " + id);
    }
    @GetMapping("/pedidos-descripcion-fecha")
    public ResponseEntity<List<Object[]>> getCocinaPedidosDescripcionOrderedByFecha() {
        List<Object[]> result = cocinaService.findCocinaPedidosDescripcionOrderedByFecha();
        return ResponseEntity.ok(result);
    }
}

