package com.example.Dalaska.Repository;

import com.example.Dalaska.Model.Meseros;

import org.springframework.data.jpa.repository.JpaRepository;

import org.springframework.stereotype.Repository;


@Repository
public interface MeserosRepository extends JpaRepository<Meseros, Long >{


}
