package com.example.Dalaska.Model;

import jakarta.persistence.Entity;
import jakarta.persistence.*;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@Entity
public class Pedidos {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
private Long idPedidos;


    @ManyToOne
    @JoinColumn(name = "cocina_id")
    private Cocina cocina;

    @ManyToOne
    @JoinColumn(name = "mesero_id")
    private Meseros mesero;

    @ManyToMany(cascade = CascadeType.ALL)
    @JoinTable(
            name = "pedido_producto",
            joinColumns = @JoinColumn(name = "pedido_id"),
            inverseJoinColumns = @JoinColumn(name = "producto_id"))
    private List<Productos> productos = new ArrayList<>();

    @OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "descripcion_id")
    private DescripcionPedidos descripcion;

    private LocalDateTime fechaCreacion;
    public Pedidos() {
    }

    public Pedidos(Long id, Cocina cocina, Meseros mesero, List<Productos> productos, DescripcionPedidos descripcion) {
        this.idPedidos = id;
        this.cocina = cocina;
        this.mesero = mesero;
        this.productos = productos;
        this.descripcion = descripcion;
    }

    public Long getId() {
        return idPedidos;
    }

    public void setId(Long id) {
        this.idPedidos = id;
    }

    public Cocina getCocina() {
        return cocina;
    }

    public void setCocina(Cocina cocina) {
        this.cocina = cocina;
    }

    public Meseros getMesero() {
        return mesero;
    }

    public void setMesero(Meseros mesero) {
        this.mesero = mesero;
    }

    public List<Productos> getProductos() {
        return productos;
    }

    public void setProductos(List<Productos> productos) {
        this.productos = productos;
    }

    public DescripcionPedidos getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(DescripcionPedidos descripcion) {
        this.descripcion = descripcion;
    }

    @Override
    public String toString() {
        return "Pedidos{" +
                "id=" + idPedidos +
                ", cocina=" + cocina +
                ", mesero=" + mesero +
                ", productos=" + productos +
                ", descripcion=" + descripcion +
                '}';
    }
}
