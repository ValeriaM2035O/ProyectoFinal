package com.example.Dalaska.Service;

import com.example.Dalaska.Model.Meseros;
import com.example.Dalaska.Repository.MeserosRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
@Service
public class MeserosService {

    @Autowired
    private MeserosRepository meserosRepository;

    public List<Meseros> getAllMeseros() {
        return meserosRepository.findAll();
    }
    public Optional<Meseros> getMeseroById(Long id) {
        return meserosRepository.findById(id);
    }
    public Meseros saveMesero(Meseros mesero) {
        return meserosRepository.save(mesero);
    }
    public void updateMesero(Long id, Meseros mesero) {
        if (meserosRepository.existsById(id)) {
            mesero.setId(id);
            meserosRepository.save(mesero);
        }
    }
    public void deleteMesero(Long id) {
        meserosRepository.deleteById(id);

    }
}
