package com.example.Dalaska.Service;

import com.example.Dalaska.Model.DescripcionPedidos;
import com.example.Dalaska.Repository.DescripcionPedidosRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class DescripcionPedidosService {

    @Autowired
    private DescripcionPedidosRepository descripcionPedidosRepository;

    public List<DescripcionPedidos> getAllDescripciones() {
        return descripcionPedidosRepository.findAll();
    }

    public Optional<DescripcionPedidos> getDescripcionById(Long id) {
        return descripcionPedidosRepository.findById(id);
    }

    public void updateDescripcion(Long id, DescripcionPedidos descripcion) {
        if (descripcionPedidosRepository.existsById(id)) {
            descripcion.setId(id);
            descripcionPedidosRepository.save(descripcion);
        }
    }

    public void deleteDescripcion(Long id) {
        descripcionPedidosRepository.deleteById(id);
    }

    public DescripcionPedidos saveDescripcion(DescripcionPedidos descripcion) {
        return descripcionPedidosRepository.save(descripcion);
    }
}
