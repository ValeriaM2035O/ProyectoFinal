package com.example.Dalaska.Repository;

import com.example.Dalaska.Model.Cocina;
import com.example.Dalaska.Model.Disponibilidad;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface DisponibilidadRepository extends JpaRepository<Disponibilidad, Long >{
    // Encuentra por disponibilidad
    @Query("SELECT d FROM Disponibilidad d WHERE d.disponible = :disponible")
    List<Disponibilidad> findByDisponible(@Param("disponible") boolean disponible);

    // Encuentra disponibilidad por el ID del producto
    @Query("SELECT d FROM Disponibilidad d JOIN FETCH d.producto p WHERE p.id = :idProducto")
    Optional<Disponibilidad> findByProductoId(@Param("idProducto") Long idProducto);

    // Actualiza el estado de disponibilidad
    @Modifying
    @Query("UPDATE Disponibilidad d SET d.disponible = :disponible WHERE d.idDisponibilidad = :id")
    void updateDisponible(@Param("id") Long id, @Param("disponible") boolean disponible);
}