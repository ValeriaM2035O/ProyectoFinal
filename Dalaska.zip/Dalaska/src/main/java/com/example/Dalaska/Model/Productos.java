package com.example.Dalaska.Model;

import jakarta.persistence.*;


import java.util.ArrayList;
import java.util.List;

@Entity
public class Productos {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long idProductos; // Cambié el nombre a 'id' para mayor claridad
    private String nombre;
    private Double precio;

    @OneToMany(mappedBy = "producto", cascade = CascadeType.ALL)
    private List<Disponibilidad> disponibilidad = new ArrayList<>();

    @ManyToMany(mappedBy = "productos")
    private List<Pedidos> pedidos = new ArrayList<>();

    public Productos() {
    }

    public Productos(Long id, String nombre, Double precio, List<Disponibilidad> disponibilidad, List<Pedidos> pedidos) {
        this.idProductos = id;
        this.nombre = nombre;
        this.precio = precio;
        this.disponibilidad = disponibilidad;
        this.pedidos = pedidos;
    }

    public Long getId() {
        return idProductos;
    }

    public void setId(Long id) {
        this.idProductos = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public Double getPrecio() {
        return precio;
    }

    public void setPrecio(Double precio) {
        this.precio = precio;
    }

    public List<Disponibilidad> getDisponibilidad() {
        return disponibilidad;
    }

    public void setDisponibilidad(List<Disponibilidad> disponibilidad) {
        this.disponibilidad = disponibilidad;
    }

    public List<Pedidos> getPedidos() {
        return pedidos;
    }

    public void setPedidos(List<Pedidos> pedidos) {
        this.pedidos = pedidos;
    }

    @Override
    public String toString() {
        return "Productos{" +
                "id=" + idProductos +
                ", nombre='" + nombre + '\'' +
                ", precio=" + precio +
                ", disponibilidad=" + disponibilidad +
                ", pedidos=" + pedidos +
                '}';
    }
}

