package com.example.Dalaska.Controller;

import com.example.Dalaska.Model.DescripcionPedidos;
import com.example.Dalaska.Service.DescripcionPedidosService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/descripcionPedidos")
public class DescripcionPedidosController {

    @Autowired
    private DescripcionPedidosService descripcionPedidosService;


    @GetMapping("/todos")
    public List<DescripcionPedidos> getAllDescripciones() {
        return descripcionPedidosService.getAllDescripciones();
    }


    @GetMapping("/{id}")
    public Optional<DescripcionPedidos> getDescripcionById(@PathVariable Long id) {
        return descripcionPedidosService.getDescripcionById(id);
    }


    @PostMapping("/guardar")
    public ResponseEntity<String> saveDescripcion(@RequestBody DescripcionPedidos descripcionPedidos) {
        descripcionPedidosService.saveDescripcion(descripcionPedidos);
        return ResponseEntity.status(HttpStatus.CREATED).body("Descripción de pedido registrada con éxito.");
    }


    @PutMapping("/{id}/actualizar")
    public ResponseEntity<String> updateDescripcion(@PathVariable Long id, @RequestBody DescripcionPedidos descripcion) {
        descripcionPedidosService.updateDescripcion(id, descripcion);
        return ResponseEntity.ok("Descripción de pedido actualizada con éxito. ID: " + id);
    }


    @DeleteMapping("/eliminar/{id}")
    public ResponseEntity<String> deleteDescripcion(@PathVariable Long id) {
        descripcionPedidosService.deleteDescripcion(id);
        return ResponseEntity.ok("Descripción de pedido eliminada con éxito. ID: " + id);
    }
}
