package com.example.Dalaska.Controller;

import com.example.Dalaska.Model.Pedidos;
import com.example.Dalaska.Service.PedidosService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping ("/pedidos")
public class PedidosController {

    @Autowired
    private PedidosService pedidosService;

    @GetMapping("/todos")
    public List<Pedidos> getAllPedidos() {
        return pedidosService.getAllPedidos();
    }

    @GetMapping("/{id}")
    public Optional<Pedidos> getPedidoById(@PathVariable Long id) {
        return pedidosService.getPedidoById(id);
    }

    @PostMapping("/guardar")
    public ResponseEntity<String> savePedido(@RequestBody Pedidos pedido) {
        Pedidos nuevoPedido = pedidosService.savePedido(pedido);
        return ResponseEntity.status(HttpStatus.CREATED)
                .body("Pedido registrado con éxito. ID: " + nuevoPedido.getId());
    }

    @PutMapping("/{id}/actualizar")
    public ResponseEntity<String> updatePedido(@PathVariable Long id, @RequestBody Pedidos pedido) {
        pedidosService.updatePedido(id, pedido);
        return ResponseEntity.ok("Pedido actualizado con éxito. ID: " + id);
    }

    @DeleteMapping("/eliminar/{id}")
    public ResponseEntity<String> deletePedido(@PathVariable Long id) {
        pedidosService.deletePedido(id);
        return ResponseEntity.ok("Pedido eliminado con éxito. ID: " + id);
    }
    @GetMapping("/by-mesero/{meseroId}")
    public ResponseEntity<List<Object[]>> getPedidosByMesero(@PathVariable Long meseroId) {
        List<Object[]> result = pedidosService.findPedidosByMesero(meseroId);
        return ResponseEntity.ok(result);
    }

    @GetMapping("/todas-tablas")
    public ResponseEntity<List<Object[]>> getAllTableData() {
        List<Object[]> result = pedidosService.findAllTableData();
        return ResponseEntity.ok(result);
    }
}
