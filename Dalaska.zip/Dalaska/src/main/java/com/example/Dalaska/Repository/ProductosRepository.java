package com.example.Dalaska.Repository;

import com.example.Dalaska.Model.Productos;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;
@Repository
public interface ProductosRepository extends JpaRepository<Productos, Long> {

    @Query("SELECT p FROM Productos p JOIN FETCH p.disponibilidad d WHERE d.cantidadDisponible > 0")
    List<Productos> findAvailableProducts();


}
