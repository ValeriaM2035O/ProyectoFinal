package com.example.Dalaska.Repository;

import com.example.Dalaska.Model.Pedidos;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
@Repository
public interface PedidosRepository extends JpaRepository<Pedidos, Long> {


    @Query("SELECT p FROM Pedidos p ORDER BY p.fechaCreacion ASC")
    List<Pedidos> findAllPedidosOrderedByDate();

    @Query(value = "SELECT p.id_pedidos, p.fecha_creacion, c.nombre AS cocina_nombre, " +
            "m.nombre AS mesero_nombre, prod.nombre AS producto_nombre, prod.precio, " +
            "dp.detalles AS descripcion_detalles " +
            "FROM pedidos p " +
            "JOIN cocina c ON p.cocina_id = c.id_cocina " +
            "JOIN meseros m ON p.mesero_id = m.id_meseros " +
            "JOIN pedido_producto pp ON p.id_pedidos = pp.pedido_id " +
            "JOIN productos prod ON pp.producto_id = prod.id_productos " +
            "LEFT JOIN descripcion_pedidos dp ON p.descripcion_id = dp.id_descripcion_pedidos",
            nativeQuery = true)
    List<Object[]> findAllTableData();

    @Query(value = "SELECT p.id_pedidos, p.fecha_creacion, m.nombre AS mesero_nombre " +
            "FROM pedidos p " +
            "JOIN meseros m ON p.mesero_id = m.id_meseros " +
            "WHERE m.id_meseros = :idMesero", nativeQuery = true)
    List<Object[]> findPedidosByMesero(@Param("idMesero") Long idMesero);

}