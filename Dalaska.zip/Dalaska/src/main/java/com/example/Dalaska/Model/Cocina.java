package com.example.Dalaska.Model;

import jakarta.persistence.*;

import java.util.ArrayList;
import java.util.List;

@Entity
public class Cocina {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long idCocina;
    private String nombre;

    @OneToMany(mappedBy = "cocina", cascade = CascadeType.ALL)
    private List<Pedidos> pedidos = new ArrayList<>();

    public Cocina() {
    }

    public Cocina(Long id, String nombre, List<Pedidos> pedidos) {
        this.idCocina = id;
        this.nombre = nombre;
        this.pedidos = pedidos;
    }

    public Long getId() {
        return idCocina;
    }

    public void setId(Long id) {
        this.idCocina = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public List<Pedidos> getPedidos() {
        return pedidos;
    }

    public void setPedidos(List<Pedidos> pedidos) {
        this.pedidos = pedidos;
    }

    @Override
    public String toString() {
        return "Cocina{" +
                "id=" + idCocina +
                ", nombre='" + nombre + '\'' +
                ", pedidos=" + pedidos +
                '}';
    }
}