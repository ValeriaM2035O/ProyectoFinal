package com.example.Dalaska.Controller;

import com.example.Dalaska.Model.Meseros;
import com.example.Dalaska.Service.MeserosService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping ("/meseros")
public class MeserosController {

    @Autowired
    private MeserosService meserosService;

    @GetMapping("/todos")
    public List<Meseros> getAllMeseros() {
        return meserosService.getAllMeseros();
    }

    @GetMapping("/{id}")
    public Optional<Meseros> getMeseroById(@PathVariable Long id) {
        return meserosService.getMeseroById(id);
    }

    @PostMapping("/guardar")
    public ResponseEntity<String> saveMesero(@RequestBody Meseros mesero) {
        Meseros nuevoMesero = meserosService.saveMesero(mesero);
        return ResponseEntity.status(HttpStatus.CREATED)
                .body("Mesero registrado con éxito. ID: " + nuevoMesero.getId());
    }

    @PutMapping("/{id}/actualizar")
    public ResponseEntity<String> updateMesero(@PathVariable Long id, @RequestBody Meseros mesero) {
        meserosService.updateMesero(id, mesero);
        return ResponseEntity.ok("Mesero actualizado con éxito. ID: " + id);
    }

    @DeleteMapping("/eliminar/{id}")
    public ResponseEntity<String> deleteMesero(@PathVariable Long id) {
        meserosService.deleteMesero(id);
        return ResponseEntity.ok("Mesero eliminado con éxito. ID: " + id);
    }
}

