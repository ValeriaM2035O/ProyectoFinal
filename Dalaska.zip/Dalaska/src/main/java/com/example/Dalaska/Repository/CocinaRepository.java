package com.example.Dalaska.Repository;

import com.example.Dalaska.Model.Cocina;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;
@Repository
public interface CocinaRepository extends JpaRepository<Cocina, Long> {
    @Query("SELECT c FROM Cocina c JOIN FETCH c.pedidos p JOIN FETCH p.descripcion d")
    List<Cocina> findCocinasWithPedidosAndDescriptions();


    @Query(value = "SELECT c.nombre AS cocina_nombre, p.id_pedidos, p.fecha_creacion, dp.detalles AS descripcion_detalles " +
            "FROM pedidos p " +
            "JOIN cocina c ON p.cocina_id = c.id_cocina " +
            "LEFT JOIN descripcion_pedidos dp ON p.descripcion_id = dp.id_descripcion_pedidos " +
            "ORDER BY p.fecha_creacion ASC",
            nativeQuery = true)
    List<Object[]> findCocinaPedidosDescripcionOrderedByFecha();

}
